package com.example.donuttpa;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class TpaScreen extends Screen {
    private EditBox playerField;
    private EditBox intervalField;

    public TpaScreen() {
        super(Component.literal("DonutTPA"));
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int top = this.height / 2 - 75;

        playerField = new EditBox(this.font, center - 100, top + 22, 200, 20,
                Component.literal("Player name"));
        playerField.setMaxLength(16);
        playerField.setHint(Component.literal("Minecraft username"));
        addRenderableWidget(playerField);

        intervalField = new EditBox(this.font, center - 100, top + 66, 200, 20,
                Component.literal("Interval in seconds"));
        intervalField.setValue(Integer.toString(TpaRepeater.intervalSeconds()));
        intervalField.setMaxLength(4);
        intervalField.setFilter(value -> value.isEmpty() || value.matches("\\d{1,4}"));
        addRenderableWidget(intervalField);

        addRenderableWidget(Button.builder(Component.literal("Start"), button -> {
            String name = playerField.getValue().trim();
            if (!name.matches("[A-Za-z0-9_]{3,16}")) {
                DonutTPAClient.message("Enter a valid Minecraft username.");
                return;
            }
            int seconds;
            try { seconds = Integer.parseInt(intervalField.getValue()); }
            catch (NumberFormatException ex) { seconds = TpaRepeater.MIN_INTERVAL_SECONDS; }
            TpaRepeater.start(name, seconds);
        }).bounds(center - 100, top + 104, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Stop"), button -> TpaRepeater.stop())
                .bounds(center + 5, top + 104, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Done"), button -> onClose())
                .bounds(center - 100, top + 132, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        super.render(graphics, mouseX, mouseY, delta);
        int center = this.width / 2;
        int top = this.height / 2 - 75;
        graphics.drawCenteredString(font, title, center, top, 0xFFFFFF);
        graphics.drawString(font, "Target player", center - 100, top + 9, 0xCFCFCF);
        graphics.drawString(font, "Interval (minimum 30 seconds)", center - 100, top + 53, 0xCFCFCF);
        String status = TpaRepeater.isRunning()
                ? "Running: /tpahere " + TpaRepeater.target()
                : "Stopped";
        graphics.drawCenteredString(font, status, center, top + 164, 0xFFFFFF);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
