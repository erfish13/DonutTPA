package com.example.donuttpa;

import net.minecraft.client.Minecraft;

final class TpaRepeater {
    // Deliberately conservative minimum interval; this is not intended to bypass server limits.
    static final int MIN_INTERVAL_SECONDS = 30;
    private static boolean running;
    private static String target = "";
    private static int intervalSeconds = 30;
    private static long nextSendTick;

    private TpaRepeater() {}

    static void start(String playerName, int seconds) {
        target = playerName.trim();
        intervalSeconds = Math.max(MIN_INTERVAL_SECONDS, Math.min(seconds, 3600));
        if (target.isEmpty()) {
            DonutTPAClient.message("Enter a player name first.");
            return;
        }
        running = true;
        nextSendTick = 0;
        DonutTPAClient.message("Repeater started for " + target + " (" + intervalSeconds + "s interval).");
    }

    static void stop() {
        running = false;
        DonutTPAClient.message("Stopped.");
    }

    static boolean isRunning() { return running; }
    static String target() { return target; }
    static int intervalSeconds() { return intervalSeconds; }

    static void tick(Minecraft client) {
        if (!running) return;
        if (client.player == null || client.getConnection() == null) {
            running = false;
            return;
        }
        long now = client.level == null ? 0 : client.level.getGameTime();
        if (nextSendTick == 0 || now >= nextSendTick) {
            DonutTPAClient.sendTpaHere(target);
            nextSendTick = now + intervalSeconds * 20L;
        }
    }
}
