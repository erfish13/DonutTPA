# DonutTPA (Minecraft Java 26.2)

A client-side Fabric mod that opens a small TPAHere control screen with **Right Shift**.

## Features

- Enter a Minecraft username.
- Start or stop sending `/tpahere <username>`.
- Configure an interval from 30 to 3600 seconds (minimum 30 seconds to avoid rapid command spam).
- The mod stops when you disconnect.

Use this only where permitted by the server. Server-side command cooldowns and anti-spam rules still apply; this mod does not bypass them.

## Build automatically on GitHub (no local Java/Gradle setup)

1. Create a new repository on GitHub (for example, `DonutTPA`).
2. Upload the **contents** of this folder to the repository's `main` branch. Make sure `.github/workflows/build.yml` is included. GitHub's web uploader may require enabling **Show hidden files** so `.github` is included.
3. Open the repository's **Actions** tab.
4. Select **Build DonutTPA** and click **Run workflow** (or wait for the first push build).
5. When the run finishes successfully, open the run and download the `DonutTPA-Minecraft-26.2` artifact.
6. Extract the downloaded artifact ZIP and put the `.jar` inside your Minecraft `mods` folder. Install Fabric Loader and Fabric API for the same Minecraft version first.

The workflow uses GitHub-hosted runners with Java 25 and Gradle 9.6.0. The resulting JAR is a build artifact, not committed back into the repository.

## Controls

- **Right Shift**: open the DonutTPA screen.
- **Start**: start the repeat sender.
- **Stop**: stop it immediately.

## Version settings

Minecraft: `26.2`  
Fabric Loader: `0.20.1`  
Fabric API: `0.161.0+26.2`  
Java toolchain: `25`
